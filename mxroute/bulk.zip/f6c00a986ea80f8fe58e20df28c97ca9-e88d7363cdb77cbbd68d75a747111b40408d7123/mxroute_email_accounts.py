import requests
import csv
import time

server_login = 'YourUserName' 
server_pass  = 'YourPassword/LoginKey'
endpoint_url = 'AddSevrerURLHereWithPort' + '/CMD_EMAIL_POP'  #Change the first part to he URL of the server you recoeved after sign up.

headers={"Content-Type": "application/x-www-form-urlencoded",}
        
data_template = '{"user":"%s","passwd2":"%s","passwd":"%s","quota":"%s","limit":"7200","domain":"%s","json":"yes","action":"create"}'

with open('users.csv', newline='\n') as csvfile:
    reader = csv.DictReader(csvfile)
    for row in reader:
        name = row['email'].split('@')[0].lower()
        domain = row['email'].split('@')[1].lower()
        password = row['password']
        quota = row['quota']
        data = data_template % (name, password, password, quota, domain)
        response = requests.post(
        endpoint_url,
        headers=headers,
        auth=(server_login, server_pass),
        data=data,
        timeout=5
        )
        print("Status: ",response.status_code," User ", name, " created !!")
        time.sleep(2)